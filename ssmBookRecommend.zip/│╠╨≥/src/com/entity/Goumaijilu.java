﻿package com.entity;

public class Goumaijilu {
    private Integer id;
	private String tushubianhao;	private String tushumingcheng;	private String tushuleibie;	private String xinjiuchengdu;	private String jiage;	private String shuliang;	private String jine;	private String beizhu;	private String goumairen;	private String issh;	
    private String addtime;

    

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
	
	public String getTushubianhao() {
        return tushubianhao;
    }
    public void setTushubianhao(String tushubianhao) {
        this.tushubianhao = tushubianhao == null ? null : tushubianhao.trim();
    }	public String getTushumingcheng() {
        return tushumingcheng;
    }
    public void setTushumingcheng(String tushumingcheng) {
        this.tushumingcheng = tushumingcheng == null ? null : tushumingcheng.trim();
    }	public String getTushuleibie() {
        return tushuleibie;
    }
    public void setTushuleibie(String tushuleibie) {
        this.tushuleibie = tushuleibie == null ? null : tushuleibie.trim();
    }	public String getXinjiuchengdu() {
        return xinjiuchengdu;
    }
    public void setXinjiuchengdu(String xinjiuchengdu) {
        this.xinjiuchengdu = xinjiuchengdu == null ? null : xinjiuchengdu.trim();
    }	public String getJiage() {
        return jiage;
    }
    public void setJiage(String jiage) {
        this.jiage = jiage == null ? null : jiage.trim();
    }	public String getShuliang() {
        return shuliang;
    }
    public void setShuliang(String shuliang) {
        this.shuliang = shuliang == null ? null : shuliang.trim();
    }	public String getJine() {
        return jine;
    }
    public void setJine(String jine) {
        this.jine = jine == null ? null : jine.trim();
    }	public String getBeizhu() {
        return beizhu;
    }
    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu == null ? null : beizhu.trim();
    }	public String getGoumairen() {
        return goumairen;
    }
    public void setGoumairen(String goumairen) {
        this.goumairen = goumairen == null ? null : goumairen.trim();
    }	public String getIssh() {
        return issh;
    }
    public void setIssh(String issh) {
        this.issh = issh == null ? null : issh.trim();
    }	
	
	
    public String getAddtime() {
        return addtime;
    }
    public void setAddtime(String addtime) {
        this.addtime = addtime == null ? null : addtime.trim();
    }
}
//   设置字段信息
