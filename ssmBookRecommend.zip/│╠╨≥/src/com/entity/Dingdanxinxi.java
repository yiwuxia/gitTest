﻿package com.entity;

public class Dingdanxinxi {
    private Integer id;
	private String dingdanhao;
	private String jine;
	private String dingdanneirong;
	private String dizhi;
	private String dianhua;
	private String xingming;
	private String yonghuming;
	private String beizhu;
	private String issh;
	private String iszf;
	
    private String addtime;

    

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
	
	public String getDingdanhao() {
        return dingdanhao;
    }
    public void setDingdanhao(String dingdanhao) {
        this.dingdanhao = dingdanhao == null ? null : dingdanhao.trim();
    }
	public String getJine() {
        return jine;
    }
    public void setJine(String jine) {
        this.jine = jine == null ? null : jine.trim();
    }
	public String getDingdanneirong() {
        return dingdanneirong;
    }
    public void setDingdanneirong(String dingdanneirong) {
        this.dingdanneirong = dingdanneirong == null ? null : dingdanneirong.trim();
    }
	public String getDizhi() {
        return dizhi;
    }
    public void setDizhi(String dizhi) {
        this.dizhi = dizhi == null ? null : dizhi.trim();
    }
	public String getDianhua() {
        return dianhua;
    }
    public void setDianhua(String dianhua) {
        this.dianhua = dianhua == null ? null : dianhua.trim();
    }
	public String getXingming() {
        return xingming;
    }
    public void setXingming(String xingming) {
        this.xingming = xingming == null ? null : xingming.trim();
    }
	public String getYonghuming() {
        return yonghuming;
    }
    public void setYonghuming(String yonghuming) {
        this.yonghuming = yonghuming == null ? null : yonghuming.trim();
    }
	public String getBeizhu() {
        return beizhu;
    }
    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu == null ? null : beizhu.trim();
    }
	public String getIssh() {
        return issh;
    }
    public void setIssh(String issh) {
        this.issh = issh == null ? null : issh.trim();
    }
	
	public String getIszf() {
        return iszf;
    }
    public void setIszf(String iszf) {
        this.iszf = iszf == null ? null : iszf.trim();
    }
	
	
	
    public String getAddtime() {
        return addtime;
    }
    public void setAddtime(String addtime) {
        this.addtime = addtime == null ? null : addtime.trim();
    }
}
//   设置字段信息
