package window;
public class BattleCity {
	public static void main(String args[]) {
		new WindowFrame();
	}
}
